using System;
using AtletaApi.Models;

namespace AtletaApi.Dtos
{
    public class EditorDTO
    {
        public EditorDTO() { }

        public EditorDTO(Editor obj)
        {
            Id = obj.Id.ToString();
            Nome = obj.Nome;
            Email = obj.Email;
            Biografia = obj.Biografia;
            DataCriacao = obj.DataCriacao.ToString("yyyy-MM-dd"); 
        }

        public string Id { get; set; } = string.Empty;
        
        public string Nome { get; set; } = string.Empty;

        public string Email { get; set; } = string.Empty;

        public string? Biografia { get; set; }  

        public string DataCriacao { get; set; } = string.Empty; 

        public Editor GetModel()
        {
            var obj = new Editor();
            PreencherModel(obj);
            return obj;
        }

        public void PreencherModel(Editor obj)
        {
            long.TryParse(this.Id, out long id);
            obj.Id = id;
            obj.Nome = this.Nome;
            obj.Email = this.Email;
            obj.Biografia = this.Biografia;
            obj.DataCriacao = DateTime.TryParse(this.DataCriacao, out DateTime dataCriacao) ? dataCriacao : DateTime.Now;
        }
    }
}
