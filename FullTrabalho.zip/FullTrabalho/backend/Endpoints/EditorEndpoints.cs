using System;
using AtletaApi.Dtos;
using AtletaApi.Infra;
using AtletaApi.Models;
using Microsoft.EntityFrameworkCore;

namespace UsuarioApi.Endpoints
{
    public static class EditorEndpoints
    {
        public static void AdicionarEditorEndpoints(this WebApplication app)
        {
            var grupo = app.MapGroup("/editors");

            
            grupo.MapGet("/", GetAsync).RequireAuthorization("AdminOuEditor");

            
            grupo.MapGet("/{id}", GetByIdAsync).RequireAuthorization("Admin");

            
            grupo.MapPost("", PostEditorAsync).RequireAuthorization("Admin");

            
            grupo.MapPut("/{id}", PutEditorAsync).RequireAuthorization("Editor");

           
            grupo.MapDelete("/{id}", DeleteEditorAsync).RequireAuthorization("Admin");
        }

        
        private static async Task<IResult> GetAsync(EditorContext db)
        {
            var editores = await db.Editors.ToListAsync();
            return TypedResults.Ok(editores.Select(x => new EditorDTO(x)));
        }

      
        private static async Task<IResult> GetByIdAsync(string id, EditorContext db)
        {
            var editor = await db.Editors.FindAsync(Convert.ToInt64(id));
            if (editor == null)
                return TypedResults.NotFound();

            return TypedResults.Ok(new EditorDTO(editor));
        }

      
        private static async Task<IResult> PostEditorAsync(EditorDTO dto, EditorContext db)
        {
            var editor = dto.GetModel();
            editor.Id = GeradorId.GetId();  
            await db.Editors.AddAsync(editor);
            await db.SaveChangesAsync();

            return TypedResults.Created($"editors/{editor.Id}", new EditorDTO(editor));
        }

        
        private static async Task<IResult> PutEditorAsync(string id, EditorDTO dto, EditorContext db)
        {
            if (id != dto.Id)
                return TypedResults.BadRequest();

            var editor = await db.Editors.FindAsync(Convert.ToInt64(id));
            if (editor == null)
                return TypedResults.NotFound();

            dto.PreencherModel(editor);
            db.Editors.Update(editor);
            await db.SaveChangesAsync();

            return TypedResults.NoContent();
        }

       
        private static async Task<IResult> DeleteEditorAsync(string id, EditorContext db)
        {
            var editor = await db.Editors.FindAsync(Convert.ToInt64(id));
            if (editor == null)
                return TypedResults.NotFound();

            db.Editors.Remove(editor);
            await db.SaveChangesAsync();

            return TypedResults.NoContent();
        }
    }
}
