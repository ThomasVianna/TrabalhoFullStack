using System;

namespace AtletaApi.Models
{
    public class Editor
    {
        public long Id { get; set; }
        
        public string Nome { get; set; } = string.Empty;
        
        public string Email { get; set; } = string.Empty;
        
        public string HashSenha { get; set; } = string.Empty;
        
        public string Role { get; set; } = "editor"; 
        
        public DateTime DataCriacao { get; set; } = DateTime.Now; 
        
        public string? Biografia { get; set; } 
        
        
    }
}
