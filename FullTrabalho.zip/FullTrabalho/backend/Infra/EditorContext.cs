using System;
using AtletaApi.Models;
using Microsoft.EntityFrameworkCore;

namespace AtletaApi.Infra
{
    public class EditorContext : DbContext
    {
        public DbSet<Editor> Editors { get; set; }  
        public DbSet<Usuario> Usuarios { get; set; }  

        private readonly string caminho;

        public EditorContext()
        {
           
            caminho = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "editors.db");
        }

       
        protected override void OnConfiguring(DbContextOptionsBuilder options)
        {
            options.UseSqlite($"Data Source={caminho}");
        }
    }
}
