import { createContext } from "react";
export const UsuarioContext = createContext([null, () => { }]);
