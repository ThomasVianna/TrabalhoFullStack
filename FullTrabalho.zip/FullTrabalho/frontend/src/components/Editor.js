import React, { useState, useEffect } from 'react';

const Editor = () => {
  const [text, setText] = useState('');
  useEffect(() => {
    const savedText = localStorage.getItem('editorText');
    if (savedText) {
      setText(savedText);
    }
  }, []);


  useEffect(() => {
    localStorage.setItem('editorText', text);
  }, [text]);

  const handleChange = (e) => {
    setText(e.target.value);
  };

  const handleSave = () => {
    alert('Texto salvo com sucesso!');
  };

  const handleClear = () => {
    setText('');
    localStorage.removeItem('editorText');
  };

  return (
    <div>
      <h2>Editor de Texto</h2>
      <textarea
        value={text}
        onChange={handleChange}
        placeholder="Biografia..."
      />
      <div>
        <button onClick={handleSave}>Salvar</button>
        <button onClick={handleClear}>Limpar</button>
      </div>
    </div>
  );
};

export default Editor;
